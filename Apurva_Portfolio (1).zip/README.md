
# Apurva Mahapatra | Portfolio Website

This portfolio was built using only **HTML and Tailwind CSS** as part of the DevTown Tailwind Bootcamp project. It includes 4 responsive sections: Home, About Me, Projects, and Contact. It showcases my skills, project experience, and academic journey. I learned how to organize content semantically and apply Tailwind utility classes effectively.

Submission Deadline: 17 July 2025
